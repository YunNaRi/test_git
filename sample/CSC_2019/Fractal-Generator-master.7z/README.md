# Fractal-Generator
C# Fractal Generator

* Shrink Rate: A percentage from 0-100 controlling how much each fork shrinks as compared to its parent
* Angle Delta: The angle that new forks are created at
* Split Depth: This is a recursive algorithm, depth controls how many forks get generated

![Image of Project](http://i.imgur.com/7wTnZzE.png)
